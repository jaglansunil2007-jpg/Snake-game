# Snake Dash

A browser-based Snake game made with HTML, CSS, and JavaScript.

## How to Run

Open `index.html` in any modern browser.

You can also open the folder in VS Code and run it with the Live Server extension.

## Controls

- Arrow keys or WASD: Move snake
- Space: Start, pause, or resume
- Mobile buttons: Move snake and pause

## Features

- Score and best score
- Increasing speed after eating food
- Keyboard and mobile touch controls
- Game over and restart screen
- Clean responsive design
