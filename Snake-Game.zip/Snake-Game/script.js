const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const scoreEl = document.getElementById("score");
const bestScoreEl = document.getElementById("bestScore");
const overlay = document.getElementById("overlay");
const overlayTitle = document.getElementById("overlayTitle");
const overlayText = document.getElementById("overlayText");
const startButton = document.getElementById("startButton");
const pauseButton = document.getElementById("pauseButton");
const statusEl = document.getElementById("status");

const gridSize = 20;
const tileCount = canvas.width / gridSize;
const startSpeed = 132;
const speedStep = 4;
const minSpeed = 68;

let snake;
let food;
let direction;
let nextDirection;
let score;
let bestScore;
let timerId;
let running;
let paused;
let speed;

function loadBestScore() {
  return Number(localStorage.getItem("snakeDashBestScore") || "0");
}

function saveBestScore(value) {
  localStorage.setItem("snakeDashBestScore", String(value));
}

function resetGame() {
  snake = [
    { x: 10, y: 10 },
    { x: 9, y: 10 },
    { x: 8, y: 10 }
  ];
  direction = { x: 1, y: 0 };
  nextDirection = { x: 1, y: 0 };
  score = 0;
  speed = startSpeed;
  paused = false;
  running = true;
  food = createFood();
  updateHud("Playing");
}

function createFood() {
  let newFood;
  do {
    newFood = {
      x: Math.floor(Math.random() * tileCount),
      y: Math.floor(Math.random() * tileCount)
    };
  } while (snake.some((part) => part.x === newFood.x && part.y === newFood.y));
  return newFood;
}

function updateHud(status) {
  scoreEl.textContent = score;
  bestScoreEl.textContent = bestScore;
  statusEl.textContent = status;
}

function drawBoard() {
  ctx.fillStyle = "#102a43";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = "rgba(255, 255, 255, 0.055)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= tileCount; i += 1) {
    const position = i * gridSize;
    ctx.beginPath();
    ctx.moveTo(position, 0);
    ctx.lineTo(position, canvas.height);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, position);
    ctx.lineTo(canvas.width, position);
    ctx.stroke();
  }
}

function drawFood() {
  const centerX = food.x * gridSize + gridSize / 2;
  const centerY = food.y * gridSize + gridSize / 2;
  ctx.fillStyle = "#e8594f";
  ctx.beginPath();
  ctx.arc(centerX, centerY, gridSize * 0.38, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#f6c85f";
  ctx.beginPath();
  ctx.arc(centerX - 3, centerY - 3, gridSize * 0.13, 0, Math.PI * 2);
  ctx.fill();
}

function drawSnake() {
  snake.forEach((part, index) => {
    const x = part.x * gridSize;
    const y = part.y * gridSize;
    ctx.fillStyle = index === 0 ? "#45d989" : "#2fbf71";
    ctx.fillRect(x + 2, y + 2, gridSize - 4, gridSize - 4);

    if (index === 0) {
      ctx.fillStyle = "#062012";
      ctx.fillRect(x + 6, y + 6, 4, 4);
      ctx.fillRect(x + 12, y + 6, 4, 4);
    }
  });
}

function draw() {
  drawBoard();
  drawFood();
  drawSnake();
}

function moveSnake() {
  direction = nextDirection;
  const head = {
    x: snake[0].x + direction.x,
    y: snake[0].y + direction.y
  };

  if (isCollision(head)) {
    endGame();
    return;
  }

  snake.unshift(head);

  if (head.x === food.x && head.y === food.y) {
    score += 10;
    bestScore = Math.max(bestScore, score);
    saveBestScore(bestScore);
    food = createFood();
    speed = Math.max(minSpeed, speed - speedStep);
    restartLoop();
  } else {
    snake.pop();
  }

  updateHud("Playing");
  draw();
}

function isCollision(head) {
  const wallHit = head.x < 0 || head.x >= tileCount || head.y < 0 || head.y >= tileCount;
  const bodyHit = snake.some((part) => part.x === head.x && part.y === head.y);
  return wallHit || bodyHit;
}

function startLoop() {
  clearInterval(timerId);
  timerId = setInterval(() => {
    if (!paused && running) {
      moveSnake();
    }
  }, speed);
}

function restartLoop() {
  if (running && !paused) {
    startLoop();
  }
}

function showOverlay(title, text, buttonText) {
  overlayTitle.textContent = title;
  overlayText.textContent = text;
  startButton.textContent = buttonText;
  overlay.classList.remove("hidden");
}

function hideOverlay() {
  overlay.classList.add("hidden");
}

function startGame() {
  resetGame();
  hideOverlay();
  draw();
  startLoop();
}

function endGame() {
  running = false;
  clearInterval(timerId);
  updateHud("Game Over");
  showOverlay("Game Over", `Your score is ${score}. Press Start or Space to play again.`, "Restart");
}

function togglePause() {
  if (!running) {
    return;
  }

  paused = !paused;
  updateHud(paused ? "Paused" : "Playing");

  if (paused) {
    showOverlay("Paused", "Press Space or the pause button to continue.", "Resume");
  } else {
    hideOverlay();
  }
}

function setDirection(newDirection) {
  const reversing =
    newDirection.x + direction.x === 0 &&
    newDirection.y + direction.y === 0;

  if (!reversing) {
    nextDirection = newDirection;
  }
}

function handleKeydown(event) {
  const keyMap = {
    ArrowUp: { x: 0, y: -1 },
    w: { x: 0, y: -1 },
    W: { x: 0, y: -1 },
    ArrowDown: { x: 0, y: 1 },
    s: { x: 0, y: 1 },
    S: { x: 0, y: 1 },
    ArrowLeft: { x: -1, y: 0 },
    a: { x: -1, y: 0 },
    A: { x: -1, y: 0 },
    ArrowRight: { x: 1, y: 0 },
    d: { x: 1, y: 0 },
    D: { x: 1, y: 0 }
  };

  if (event.code === "Space") {
    event.preventDefault();
    if (!running) {
      startGame();
    } else {
      togglePause();
    }
    return;
  }

  const newDirection = keyMap[event.key];
  if (newDirection) {
    event.preventDefault();
    setDirection(newDirection);
  }
}

function handleControlClick(event) {
  const directionName = event.currentTarget.dataset.direction;
  const directions = {
    up: { x: 0, y: -1 },
    down: { x: 0, y: 1 },
    left: { x: -1, y: 0 },
    right: { x: 1, y: 0 }
  };

  setDirection(directions[directionName]);
}

bestScore = loadBestScore();
score = 0;
running = false;
paused = false;
updateHud("Ready");
resetGame();
running = false;
draw();
showOverlay("Snake Dash", "Press Start or Space to begin.", "Start Game");

startButton.addEventListener("click", () => {
  if (running && paused) {
    togglePause();
  } else {
    startGame();
  }
});

pauseButton.addEventListener("click", togglePause);
document.addEventListener("keydown", handleKeydown);
document.querySelectorAll("[data-direction]").forEach((button) => {
  button.addEventListener("click", handleControlClick);
});
